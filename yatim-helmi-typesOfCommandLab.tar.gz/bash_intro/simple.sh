#!/bin/bash
name="Star Lord"
# This uses double quotes, which expands the variable
echo "Hello $name"
# This uses single quotes, which does not expand the variable
echo 'Hello $name'
