#!/bin/bash
read -p "Please enter your name: " name
read -p "Please enter your favorite color " color
echo "$name, thanks for letting me know your favorite color is $color"
