1 #!/bin/bash
cmd="ls -alF"
result=$($cmd)
echo "Your directory listing: "
echo "$result"
