#!/bin/bash
# £1 is your name
# £2 is your favorite color
echo "Welcome $1. I like the color $2 also!"
