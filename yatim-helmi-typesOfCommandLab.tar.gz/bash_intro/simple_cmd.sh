#!/bin/bash
echo "Your directory listing: "
ls -alF
echo "Your current working diretory"
cmd="pwd"
$cmd
