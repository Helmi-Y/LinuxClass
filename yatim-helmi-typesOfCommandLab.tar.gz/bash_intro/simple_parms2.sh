#!/bin/bash
echo "Your passed in $# parameters!"
