# Count the number of lines that contain the string "nevermore" regardless of case. Return only the count.
echo "Problem 9"
grep -ic 'nevermore' raven.txt
