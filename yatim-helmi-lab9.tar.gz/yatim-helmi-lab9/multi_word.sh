# Return all lines that contain the strings "rep", "word", or "more"
echo "Problem 3"
grep 'rep\|word\|more' raven.txt
