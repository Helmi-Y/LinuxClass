# Return all lines that contain the string ”raven”.
echo "Problem 1"
grep raven raven.txt
