# Count the number of lines that contain the string ”whose”. Return only the count.
echo "Problem 8"
grep -c 'whose' raven.txt
