# Return all lines that contain the characters "v", "z", "j", or "I" (uppercase "i").
echo "Problem 4"
grep [vzjI] raven.txt
