# Return all lines that contain the string ”more”, but do not return strings that contain partial matches, e.g., ’Nevermore’.
echo "Problem 7"
grep -w 'more' raven.txt
