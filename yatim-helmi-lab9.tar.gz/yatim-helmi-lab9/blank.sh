# Return the line numbers of all blank lines (find lines that start and end with nothing in between).
echo "Problem 2"
grep -n ^$ raven.txt
