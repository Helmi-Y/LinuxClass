# Return all lines that end with a dash ”-”
echo "Problem 5"
grep '\-$' raven.txt
