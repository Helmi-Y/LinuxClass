#!/bin/bash
myvar="one eyed one horned flying purple people eater"
varlen=${#myvar}
echo "String length is $varlen"

