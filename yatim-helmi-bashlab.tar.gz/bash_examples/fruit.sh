#!/bin/bash
for fruit in apples bananas pears
do
    echo $fruit
done
