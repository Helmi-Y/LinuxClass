#!/bin/bash
for arg
do
    echo $arg
done
echo
