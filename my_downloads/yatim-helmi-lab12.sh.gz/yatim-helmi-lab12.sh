# lab12

# -- Instructions --
# 1) Use scp or rsync to download this file to your local computer
# 2) Use the 'mv' command to rename this file to 'latname-firstname-lab12_dn.sh'
# 3) Change the permission so user and group have read permissions only
# 6) IMPORTANT: To get full credit for this lab complete the following steps
#       a) Using scp or rsync  upload this file with its changes to the class server at /home/shared/lab12/upload/
#       b) Submit this script with its changes to Blackboard
#           - Make sure to check the file format under "Submission Details" before submitting
